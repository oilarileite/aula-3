# Processos estocásticos, Estacionariedade e Distribuições de Probabilidade
## Slides e código para aula 3 de Econometria Avançada- Séries Temporais na USJT
